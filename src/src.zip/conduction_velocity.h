/**
 * ARRITMIC3D
 *
 * (C) CoMMLab-UV 2023
 *
 * @file conduction_velocity.h
 *
 * @brief Classes to implement the conduction velocity evolution of a cell.
 *
 * Essentially, it is the evolution of the conduction velocity along time.
 * The basic interface includes a method to get the conduction velocity at a given time.
 *
 * */

#ifndef CONDUCTION_VELOCITY_H
#define CONDUCTION_VELOCITY_H

#include "spline2D.h"
#include "node.h"
#include "node_parameters.h"

/**
 * @brief Conduction velocity model based on step function.
 *
 * This model considers constant CV between updates.
 */
class ConductionVelocity
{
public:
    /**
     * @brief Default constructor.
     *
     */
    ConductionVelocity()
    {
        this->parameters = nullptr;
        this->cv = INITIAL_CV;
    };


    static void InitModel(const std::string &path)
    {
        splines.Init(path);
    }

    /**
     * @brief Initialize the conduction velocity.
     *
     * @param parameters Pointer to the node parameters.
     * @param type Cell type.
     * @param cv_ Initial conduction velocity.
     */
    void Init(NodeParameters* parameters, CellType type, float cv_ = INITIAL_CV)
    {
        this->parameters = parameters;
        SetRestitutionModel(type);
        this->cv = cv_;
    };

    void InitWithAPD(NodeParameters* parameters, CellType type, float di_, float apd_)
    {
        this->parameters = parameters;
        SetRestitutionModel(type);
        if(di_ < 0.0 || apd_ < 0.0 || type == CELL_TYPE_VOID)
            this->cv = INITIAL_CV;
        else
            this->cv = this->restitution_model->getValue(apd_, di_)*this->parameters->correction_factor_cv;
    };

    /**
     * @brief Set the restitution model.
     *
     * @param type Cell type.
     */
    void SetRestitutionModel(CellType type)
    {
        this->restitution_model = splines.getSpline(type);
        if(this->restitution_model == nullptr && type != CELL_TYPE_VOID)
            throw std::runtime_error("conduction_velocity.h: no CV restitution model found for cell type " + std::to_string(static_cast<int>(type)));
    };

    /**
     * @brief Recompute the conduction velocity after an activation.
     *
     * @param di Diastolic interval.
     */
    void Activate(float di,float apd)
    {
        float new_cv = this->restitution_model->getValue(apd, di);
        if(! restitution_model->is_novalue(new_cv) )
        {
            new_cv *= this->parameters->correction_factor_cv;
            this->cv = this->parameters->cv_memory_coeff*this->cv + (1.0 - this->parameters->cv_memory_coeff)*new_cv;  // Inertia
        }
    };

   /**
     * @brief Recompute the conduction velocity after an activation taking
     * into account the electrotonic effect.
     *
     * @param di Diastolic interval.
     * @param avg_cv Average conduction velocity.
     * @param e_eff Electrotonic effect.
     */
    void Activate(float di, float apd, float avg_cv, float e_eff = 0.0)
    {
        Activate(di, apd);
        this->cv = this->cv*(1.0 - e_eff) + avg_cv*e_eff;
    };

    /**
     * @brief Get the conduction velocity.
     *
     * @return The conduction velocity.
     */
    float getConductionVelocity() const
    {
        return this->cv;
    };

    /**
     * Save the state of the model to a file.
     * The correct restitution model will be set when loading according to the cell type.
     */
    void SaveState(std::ofstream & f) const
    {
        f.write( (char *) &cv, sizeof(float) );
    }

    /**
     * Load the state of the model from a file.
     * The correct restitution model will be set according to the cell type.
     */
    void LoadState(std::ifstream & f, CellType type, NodeParameters* params)
    {
        this->parameters = params;
        f.read( (char *) &cv, sizeof(float) );

        SetRestitutionModel(type);
    }

private:
    NodeParameters*  parameters;         ///< @brief Parameters of the Node

    float cv; ///< Conduction velocity.
    static constexpr float INITIAL_CV = 1.0; ///< Initial conduction velocity.

    Spline2D * restitution_model; ///< APD restitution model.
    static SplineContainer2D splines; ///< Container of APD restitution models.

    static std::string config_file; /**< Configuration file for the model. */

};

std::string ConductionVelocity::config_file = "";

SplineContainer2D ConductionVelocity::splines;

#endif // CONDUCTION_VELOCITY_H